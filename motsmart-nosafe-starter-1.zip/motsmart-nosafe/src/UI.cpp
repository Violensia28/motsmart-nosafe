#include <Arduino.h>
#include "UI.h"

void UI::begin() {
#if USE_UI
  // Inisialisasi OLED/Encoder di sini jika diperlukan
#endif
}

void UI::tick(const String& statusText) {
#if USE_UI
  // Render ke OLED, ikon status, dsb.
#else
  static unsigned long last = 0;
  if (millis() - last > 1000) {
    last = millis();
    Serial.print("[UI] Status: ");
    Serial.println(statusText);
  }
#endif
}
