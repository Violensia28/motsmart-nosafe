#include <Arduino.h>
#include "Config.h"
#include "Safety.h"
#include "Logger.h"

static SafetyStatus g_status;
static uint32_t lastTick = 0;

void Safety::begin() {
  g_status = {false, false, String("INIT")};
  lastTick = millis();
}

static bool checkSD() {
#if HAS_SD
  // TODO: Implementasi SD nyata
  return true;
#else
  return false; // Tidak ada SD -> warning saja
#endif
}

static bool checkSensors() {
#if HAS_SENSORS
  // TODO: Implementasi sensor nyata
  return true;
#else
  return false; // Tidak ada sensor -> warning saja
#endif
}

void Safety::tick() {
  const uint32_t now = millis();
  if (now - lastTick < 200) return; // 5 Hz
  lastTick = now;

  const bool sd = checkSD();
  const bool sens = checkSensors();

  g_status.sdPresent = sd;
  g_status.sensorsOK = sens;

  if (sd && sens) {
    g_status.statusText = String("OK");
  } else if (!sd && sens) {
    g_status.statusText = String("WARN: SD");
    logRecord("WARN: SD not detected");
  } else if (sd && !sens) {
    g_status.statusText = String("WARN: SENS");
    logRecord("WARN: sensor missing");
  } else {
    g_status.statusText = String("WARN: SD+SENS");
    logRecord("WARN: SD not detected; sensor missing");
  }
}

SafetyStatus Safety::getStatus() {
  return g_status;
}
