#include <Arduino.h>
#include "Config.h"
#include "Safety.h"
#include "UI.h"
#include "Logger.h"
#include "Version.h"

// State machine sederhana untuk siklus las non-blocking
enum class WeldState { Idle, Preheat, Main, Cooldown };
static WeldState state = WeldState::Idle;
static uint32_t stateStart = 0;

static void setOutput(bool on) {
  digitalWrite(PIN_WELD_OUTPUT, on ? HIGH : LOW);
}

static void gotoState(WeldState s) {
  state = s;
  stateStart = millis();
}

static void weldTick() {
  const uint32_t t = millis() - stateStart;
  switch (state) {
    case WeldState::Idle:
      // Menunggu trigger
      if (digitalRead(PIN_WELD_TRIGGER) == HIGH) {
        logRecord("Trigger received");
        gotoState(WeldState::Preheat);
      }
      break;
    case WeldState::Preheat:
      setOutput(true);
      if (t >= PULSE_PREHEAT_MS) {
        setOutput(false);
        gotoState(WeldState::Main);
      }
      break;
    case WeldState::Main:
      setOutput(true);
      if (t >= PULSE_MAIN_MS) {
        setOutput(false);
        gotoState(WeldState::Cooldown);
      }
      break;
    case WeldState::Cooldown:
      if (t >= PULSE_COOLDOWN_MS) {
        gotoState(WeldState::Idle);
      }
      break;
  }
}

void setup() {
  Serial.begin(115200);
  delay(50);
  pinMode(PIN_WELD_TRIGGER, INPUT_PULLDOWN);
  pinMode(PIN_WELD_OUTPUT, OUTPUT);
  setOutput(false);

  Safety::begin();
  UI::begin();

  logRecord(String("Boot NOSAFE ") + FW_VERSION_STR + " (git " + FW_GIT_HASH + ")");
}

void loop() {
  Safety::tick();
  const auto s = Safety::getStatus();

  // NOSAFE: apapun statusnya, welding tetap boleh
  UI::tick(s.statusText);

  weldTick();
}
