#include <Arduino.h>
#include "Logger.h"

bool sdOK() {
  // NOSAFE template: asumsi SD tidak ada -> false
  return false;
}

void logRecord(const String& msg) {
  // Selalu ke Serial; jika ada SD di proyek nyata, tambahkan append ke file
  Serial.print("[LOG] ");
  Serial.println(msg);
}
