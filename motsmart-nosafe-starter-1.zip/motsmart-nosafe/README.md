# MOTSMART NOSAFE Starter Repo

> Variant: **NOSAFE** (non-blocking safety). Jika SD card atau sensor tidak terbaca, sistem **hanya menampilkan notifikasi** (log + UI status) dan **tetap mengizinkan proses spot weld**.

## Fitur Utama
- **Non-blocking safety**: peringatan (warning) tanpa interlock.
- **GitHub Actions**: build matrix (minimal + full), cache pip/PlatformIO, artifacts `.bin`, otomatis rilis saat tag.
- **.bin artifacts**: dikumpulkan ke folder `ci_build/` dan diattach saat rilis.
- **Template state machine**: loop utama tetap responsif (tanpa `while` blocking).

## Struktur
```
.github/workflows/ci_nosafe.yml
platformio.ini
src/
  main.cpp
  Safety.cpp
  UI.cpp
  Logger.cpp
include/
  Config.h
  Safety.h
  UI.h
  Logger.h
  Version.h (dibuat otomatis oleh script)
scripts/
  make_version.py
  post_build.py
ci_build/
  .gitkeep
```

## Prinsip NOSAFE
- Jika SD **tidak terpasang**: tampilkan ikon/status SD merah/abu + `logRecord("WARN: SD not detected")`. **Proses las tetap boleh**.
- Jika sensor **tidak terbaca**: tampilkan ikon/status sensor merah/abu + `logRecord("WARN: sensor missing")`. **Proses las tetap boleh**.
- Safety tetap ada (flag, telemetry), namun **tidak memblok** eksekusi pulse.

## Build Lokal
```bash
# 1) Install PlatformIO CLI
pip install -U platformio

# 2) Build kedua environment
pio run -e nosafe_minimal -e nosafe_full

# 3) Firmware ada di .pio/build/<env>/firmware.bin
```

## Rilis Otomatis
- Buat tag, misalnya `v0.3-nosafe-r1` lalu push:
```bash
git tag v0.3-nosafe-r1
git push origin v0.3-nosafe-r1
```
- GitHub Actions akan membuat **Release** dan attach `.bin` + `build.log`.

## Catatan Playbook Penting
- YAML **ASCII-only**, tanpa TAB/CRLF.
- **Jangan** bikin file/folder bernama `envlist`.
- Makro WiFi/OTA wajib **escaped quotes**.
- Header case-sensitive: gunakan `Config.h` (bukan `config.h`).
- Sinkron API Logger (`logRecord`, `sdOK`).
- Simpan log build: `build.log` saat gagal.
- Cache pip/PIO di workflow untuk build lebih cepat.

## Migrasi dari Repo Lama
1. Buat repo baru (kosong) di GitHub: `motsmart-nosafe`.
2. Salin file proyek lama yang masih relevan (src/lib) **secara selektif**, hindari dependensi yang memaksa blocking safety.
3. Tempelkan struktur dari paket ini (khususnya `platformio.ini` dan `.github/workflows/ci_nosafe.yml`).
4. Adaptasikan call site API:
   - Ganti interlock blocking menjadi **warning-only** via `Safety::getStatus()`.
   - Logging gunakan `logRecord()`.
5. Commit & push.

Selamat membangun! 🚀
