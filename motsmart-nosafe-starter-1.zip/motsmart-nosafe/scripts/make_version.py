# -*- coding: utf-8 -*-
from pathlib import Path
import subprocess
import os

ROOT = Path(__file__).resolve().parents[1]
VER_H = ROOT / 'include' / 'Version.h'

def git(cmd):
    try:
        out = subprocess.check_output(cmd, cwd=str(ROOT), stderr=subprocess.DEVNULL).decode().strip()
        return out
    except Exception:
        return ''

ver = git(['git', 'describe', '--tags', '--always', '--dirty']) or '0.0.0-dev'
sha = git(['git', 'rev-parse', '--short', 'HEAD']) or '0000000'

content = f