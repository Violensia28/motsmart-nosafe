# -*- coding: utf-8 -*-
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
CI = ROOT / 'ci_build'
PIO = ROOT / '.pio' / 'build'
CI.mkdir(exist_ok=True)

manifest = {}
if PIO.exists():
    for env in PIO.iterdir():
        fw = env / 'firmware.bin'
        if fw.exists():
            out = CI / f'firmware-{env.name}.bin'
            shutil.copy2(fw, out)
            manifest[env.name] = str(out.name)

(CI / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('[post_build] Manifest written:', manifest)
