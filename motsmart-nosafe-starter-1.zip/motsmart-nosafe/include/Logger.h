#pragma once
#include <Arduino.h>

bool sdOK();
void logRecord(const String& msg);
