#pragma once
#include <Arduino.h>

namespace UI {
  void begin();
  void tick(const String& statusText);
}
