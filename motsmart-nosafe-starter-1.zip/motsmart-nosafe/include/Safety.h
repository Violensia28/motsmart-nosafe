#pragma once
#include <Arduino.h>

struct SafetyStatus {
  bool sdPresent;
  bool sensorsOK;
  String statusText;   // Ringkas: "OK" / "WARN: SD" / "WARN: SENS" / "WARN: SD+SENS"

  bool canWeld() const { return true; } // NOSAFE: selalu boleh
};

namespace Safety {
  void begin();
  SafetyStatus getStatus();
  void tick();
}
