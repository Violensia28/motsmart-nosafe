#pragma once
#define FW_VERSION_STR "0.0.0-dev"
#define FW_GIT_HASH     "0000000"
