#pragma once

// ========== Config.h (NOSAFE variant) ==========
// Prinsip: Safety non-blocking. Jika SD/sensor tidak ada -> WARNING saja.

// Pulse default (ms)
#define PULSE_PREHEAT_MS   30
#define PULSE_MAIN_MS      80
#define PULSE_COOLDOWN_MS  150

// I/O pin contoh (silakan sesuaikan hardware)
#define PIN_WELD_TRIGGER   23
#define PIN_WELD_OUTPUT    22

// Simulasi sensor (jika tidak ada hardware)
#define HAS_SENSORS        0

// SD optional
#define HAS_SD             0
